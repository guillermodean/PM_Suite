import time

def fancy_print(message):
    # Add some space before the message
    print("\n" + "-"*40)
    print(f"  {message}")
    # Add a delay for a more dramatic effect
    time.sleep(0.5)

# Example usage:
